Macro Recorder Portable Edition - Installation
---------------------------------------------

Bitte kopieren Sie zur Verwendung von Macro Recorder 
den Inhalt dieser Archivdatei in ein beliebiges 
Verzeichnis eines portablen Speichermediums.

Wenn Sie das Programm von einem portablen Speicher 
aufrufen, wird es automatisch im portablen Modus 
gestartet, der in der Titelzeile des Programmfensters
gekennzeichnet wird.

Bei Start von einer Festplatte k�nnen Sie den portablen Modus 
mit dem Kommandozeilen-parameter "-portable" (ohne "") 
erzwingen.

Internetseite: https://www.macrorecorder.com/de/
 
--

Please copy all files of this ZIP archive into any
directory on a portable memory device.

If you launch the software from a portable memory 
device, it should launch in portable mode (indicated
in the title bar of the program window).

To enforce portable mode, launch the program with the 
commandline parameter "-portable" (without "").

Website: https://www.macrorecorder.com

� 2018 Bartels Media GmbH